var app = new Vue({
  el: '#top',
  data: {
    message: 'Vue Data Binding',
  }
})

var app = new Vue({
  el: '#tp',
  data: {
    topic: 'Profile',
  }
})

var app = new Vue({
  el: '#Myname',
  data: {
    name: 'Sahansawat suya',
    message:'I am 21 years old. I study at Maejo University. Computer Science'
  }
})

var app = new Vue({
  el: '#app',
  data: {
    message: 'Status',
  }
})

var app = new Vue({
  el: '#app0',
  data: {
    message1: 'Work',
    message2: 'Learn',
    message3: 'Sleep',
  }
})

var app = new Vue({
  el: '#new',
  data: {
    message: 'New Work',
    message1: '2',
  }
})

var app = new Vue({
  el: '#work',
  data: {
    message: 'All Work',
    message1: '10',
  }
})

var app = new Vue({
  el: '#ss',
  data: {
    message1: 'Facebook',
    message2: '20 Follower',
    message3: 'Twitter',
    message4: '4 Follower',
    message5: 'Instagram',
    message6: '441 Follower',
  }
})
